import React, { useEffect } from 'react'
import axios from 'axios';
import { Link, useNavigate }  from 'react-router-dom';

const ProductList = (props) => {
    const {productList, setProductList} = props;
    const navigate = useNavigate();
    
    useEffect(()=>{
        axios.get("http://localhost:8000/api/products")
        .then((res)=>{
            console.log(res.data);
            setProductList(res.data);
        })
        .catch((err)=> console.log(err))
    }, [])
    const deleteFilter = (idFromBelow) => {
        axios.delete('http://localhost:8000/api/products/${idFromBelow}')
            .then((res) => {
                console.log(res.data);
                setProductList(productList.filter((product, index) => product._id !== idFromBelow))
            })
            .catch((err) => {
                console.log(err);
            });
    };
    
    return (
        <div>
            <h1>All Products:</h1>
            {
                productList.map((product, index) => (
                    <div key={index}>
                        <Link to={'/products/${product_id'}>{product.title}</Link>
                        <br/>
                        <button onClick={() => navigate('/products/edit/${product._id}')}> Edit </button>
                        <button onClick={() => deleteFilter(product._id)}> Delete </button>
                    </div>
                ))
            }
        </div>
    )
}
export default ProductList;