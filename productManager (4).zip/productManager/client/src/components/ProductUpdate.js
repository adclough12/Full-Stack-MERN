import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";

const ProductUpdate = (props) => {
    const { id } = useParams();
    const [title, setTitle] = useState("");
    const [price, setPrice] = useState("");
    const [description, setDescription] = useState("");

    const navigate = useNavigate();
    const [headerTitle, setHeaderTitle] = useState("");

    useEffect(() => {
        axios
            .get(`http://localhost:8000/api/products/${id}`)
            .then((res) => {
                console.log(res.data);
                setTitle(res.data.title);
                setPrice(res.data.price);
                setDescription(res.data.description);
                setHeaderTitle(res.data.title);
            })
            .catch((err) => console.log(err));
    }, []);

    const onSubmitHandler = (e) => {
        e.preventDefault();

        axios.put(`http://localhost:8000/api/products/${id}`, { 
                title, 
                price,
                description,
            })
            .then((res) => {
                console.log(res);
                console.log(res.data);
                navigate("/");
            })
            .catch((err) => {
                console.log(err);
            });
    };

    return (
        <div>
            <header>Edit {headerTitle}</header>

            <form onSubmit={onSubmitHandler}>
                <div className="form-fields">
                    <label>Title</label>
                    <input type="text" onChange={(e) => setTitle(e.target.value)} name="title" value={title}
                    />
                </div>

                <br />

                <div className="form-fields">
                    <label>Price</label>
                    <input type="number" onChange={(e) => setPrice(e.target.value)} name="price" value={price}
                    />
                </div>

                <br />

                <div className="form-fields">
                    <label>Description</label>
                    <input type="text" onChange={(e) => setDescription(e.target.value)} name="description" value={description}
                    />
                </div>

                <br />
                {/* Could also be a button element. Try it! */}
                <input class="submit-input" type="submit" value="Update" />
            </form>
        </div>
    );
};

export default ProductUpdate;