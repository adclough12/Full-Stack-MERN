import React from "react";
import {BrowserRouter, Routes, Route} from 'react-router-dom';
import OneProduct from './components/OneProduct';
import ProductUpdate from './components/ProductUpdate';
import Main from './view/Main';

function App() {
    return (
        <BrowserRouter>
            <div className="App">
                <Routes>
                    <Route path="/" element={<Main />} />
                    <Route path="/products/:id" element={<OneProduct />}/>
                    <Route path="/products/edit/:id" element={<ProductUpdate />}/>
                </Routes>
            </div>
        </BrowserRouter>
    );
}

export default App;