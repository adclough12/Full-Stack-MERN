const Author = require("../models/author.model")

module.exports = {
    findAll: (req, res) => {
        Author.find()
            .then( allAuthors => res.status(200).json(allAuthors))
            .catch( err => res.status(400).json(err))
    },

    findOne: (req, res) => {
        Author.findById(req.params.id)
            .then( oneAuthor => res.status(400).json(oneAuthor))
            .catch( err => res.status(400).json(err))
    },

    create: (req, res) => {
        Author.create(req.body)
            .then( newAuthor => res.status(200).json(newAuthor))
            .catch( err => res.status(400).json(err))
    },

    update: (req, res) => {
        Author.findByIdAndUpdate(req.params.id, req.body)
            .then( updatedAuthor => res.status(200).json(updatedAuthor))
            .catch( err => res.status(400).json(err))
    },

    delete: (req, res) => {
        Author.findByIdAndDelete(req.params.id)
            .then( deletedAuthor => res.status(200).json(deletedAuthor))
            .catch( err => res.status(400).json(err))
    }
}