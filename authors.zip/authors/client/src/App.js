import './App.css';
import { BrowserRouter, Route, Routes } from "react-router-dom";
import DisplayAll from "./componenets/DisplayAll";
import AuthorForm from "./componenets/AuthorForm";
import UpdateAuthor from './componenets/UpdateAuthor';

function App() {
  return (
    <div className="App">
      <h1> Favorite Authors</h1>
      <BrowserRouter>
        <Routes>
          <Route path="/" element= {<DisplayAll/>} />
          <Route path="/new" element= {<AuthorForm/>}/>
          <Route path="/edit/:id" element= {<UpdateAuthor/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
